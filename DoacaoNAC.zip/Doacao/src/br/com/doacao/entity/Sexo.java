package br.com.doacao.entity;

public enum Sexo {
	FEMININO, MASCULINO, NAODECLARADO
}
