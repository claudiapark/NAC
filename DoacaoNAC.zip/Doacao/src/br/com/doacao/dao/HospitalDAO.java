package br.com.doacao.dao;

import br.com.doacao.entity.Hospital;

public interface HospitalDAO extends GenericDAO<Hospital, Integer>{

}
