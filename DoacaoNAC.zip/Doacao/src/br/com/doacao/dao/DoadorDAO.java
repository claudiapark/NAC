package br.com.doacao.dao;

import br.com.doacao.entity.Doador;

public interface DoadorDAO extends GenericDAO<Doador, Integer> {

}
