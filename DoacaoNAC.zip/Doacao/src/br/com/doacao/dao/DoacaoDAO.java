package br.com.doacao.dao;


import br.com.doacao.entity.Doacao;


public interface DoacaoDAO extends GenericDAO<Doacao,Integer>{
	

	
	
	
}
